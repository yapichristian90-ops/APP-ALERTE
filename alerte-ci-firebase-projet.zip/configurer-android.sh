#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
# Configure le projet Android généré par Capacitor pour :
#   · les notifications push Firebase (écran verrouillé / app fermée)
#   · les permissions micro, GPS, notifications, vibration, réveil
#   · un canal de notification haute priorité pour les alertes d'urgence
# Ce script est idempotent : relançable sans casser quoi que ce soit.
# ═══════════════════════════════════════════════════════════════════════
set -e

echo "▶ Configuration du projet Android…"

APP=android/app
MANIFEST=$APP/src/main/AndroidManifest.xml
BUILD_GRADLE=$APP/build.gradle
ROOT_GRADLE=android/build.gradle

# ── 1. Plugin Google Services au niveau projet ─────────────────────────
if ! grep -q "google-services" "$ROOT_GRADLE"; then
  # Ajoute le classpath du plugin dans le bloc buildscript/dependencies
  if grep -q "dependencies {" "$ROOT_GRADLE"; then
    sed -i '0,/dependencies {/s//dependencies {\n        classpath "com.google.gms:google-services:4.4.2"/' "$ROOT_GRADLE"
  fi
  echo "  ✓ Plugin google-services ajouté (niveau projet)"
else
  echo "  · google-services déjà présent au niveau projet"
fi

# ── 2. Appliquer le plugin + dépendances Firebase (niveau app) ─────────
if ! grep -q "com.google.gms.google-services" "$BUILD_GRADLE"; then
  echo '
apply plugin: "com.google.gms.google-services"

dependencies {
    implementation platform("com.google.firebase:firebase-bom:33.1.2")
    implementation "com.google.firebase:firebase-messaging"
}
' >> "$BUILD_GRADLE"
  echo "  ✓ Firebase Messaging ajouté (niveau app)"
fi

# ── 3. Permissions dans le manifest ────────────────────────────────────
# Insérées juste après la balise <manifest ...> si absentes.
add_perm() {
  local perm="$1"
  if ! grep -q "android.permission.$perm" "$MANIFEST"; then
    sed -i "0,/<manifest[^>]*>/s##&\n    <uses-permission android:name=\"android.permission.$perm\" />#" "$MANIFEST"
    echo "  ✓ Permission $perm"
  fi
}
add_perm "RECORD_AUDIO"
add_perm "ACCESS_FINE_LOCATION"
add_perm "ACCESS_COARSE_LOCATION"
add_perm "VIBRATE"
add_perm "POST_NOTIFICATIONS"
add_perm "WAKE_LOCK"
add_perm "FOREGROUND_SERVICE"
add_perm "FOREGROUND_SERVICE_LOCATION"
add_perm "INTERNET"

# ── 4. Métadonnées du canal de notifications d'urgence ─────────────────
# Un canal Android à importance MAX = son + affichage sur écran verrouillé.
if ! grep -q "default_notification_channel_id" "$MANIFEST"; then
  sed -i "s#</application>#    <meta-data android:name=\"com.google.firebase.messaging.default_notification_channel_id\" android:value=\"urgences_alerte_ci\" />\n        <meta-data android:name=\"com.google.firebase.messaging.default_notification_color\" android:resource=\"@color/colorPrimary\" />\n    </application>#" "$MANIFEST"
  echo "  ✓ Canal de notification d'urgence déclaré"
fi

# ── 5. Couleur de la notification (ressource) ──────────────────────────
COLORS=$APP/src/main/res/values/colors.xml
mkdir -p "$(dirname "$COLORS")"
if [ ! -f "$COLORS" ]; then
  cat > "$COLORS" << 'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#DC2626</color>
</resources>
XML
  echo "  ✓ Couleur de notification créée"
elif ! grep -q "colorPrimary" "$COLORS"; then
  sed -i 's#</resources>#    <color name="colorPrimary">#DC2626</color>\n</resources>#' "$COLORS"
fi

echo "▶ Configuration terminée avec succès."
