// ═══════════════════════════════════════════════════════════════════════
// EDGE FUNCTION — envoi des notifications push d'urgence via Firebase
//
// Déclenchée automatiquement quand une urgence est insérée dans la table
// « diffusions ». Elle lit les numéros ciblés, retrouve leurs jetons
// d'appareil, et demande à Firebase de réveiller ces téléphones — même
// écran verrouillé ou application fermée.
//
// Déploiement : voir le guide GUIDE-INSTALLATION.md, section « Notifications ».
// ═══════════════════════════════════════════════════════════════════════

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Fournis via les secrets Supabase (voir le guide) :
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
// Clé du compte de service Firebase (JSON complet, en secret) :
const FIREBASE_SA = Deno.env.get("FIREBASE_SERVICE_ACCOUNT")!;

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

// ── Obtenir un jeton d'accès Google (OAuth2) à partir du compte de service ──
async function getAccessToken(): Promise<string> {
  const sa = JSON.parse(FIREBASE_SA);
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "RS256", typ: "JWT" };
  const claim = {
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  };
  const enc = (o: unknown) =>
    btoa(JSON.stringify(o)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const unsigned = `${enc(header)}.${enc(claim)}`;

  // Importer la clé privée et signer
  const pem = sa.private_key
    .replace(/-----BEGIN PRIVATE KEY-----/, "")
    .replace(/-----END PRIVATE KEY-----/, "")
    .replace(/\s/g, "");
  const bin = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8", bin.buffer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned),
  );
  const jwt = `${unsigned}.${btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")}`;

  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });
  const d = await r.json();
  return d.access_token;
}

// ── Normaliser un numéro (10 derniers chiffres) ──
const norm = (p: string) => String(p || "").replace(/\D/g, "").slice(-10);

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    // Le déclencheur envoie la ligne insérée dans body.record
    const payload = body.record?.payload || body.payload || body;
    if (!payload || !payload.urgence || payload.fin) {
      return new Response("Rien à envoyer", { status: 200 });
    }

    const cibles: string[] = (payload.cibles || []).map(norm);
    if (!cibles.length) return new Response("Aucune cible", { status: 200 });

    // Retrouver les jetons des appareils ciblés
    const { data: tokens } = await supabase
      .from("device_tokens")
      .select("token, telephone")
      .in("telephone", cibles);

    if (!tokens || !tokens.length) {
      return new Response("Aucun appareil enregistré", { status: 200 });
    }

    const projectId = JSON.parse(FIREBASE_SA).project_id;
    const accessToken = await getAccessToken();

    const victime = payload.victime?.nm || "Un proche";
    const estGps = payload.type === "gps";
    const titre = estGps ? "📍 Suivi de position en direct" : "🚨 ALERTE URGENCE";
    const corps = estGps
      ? `${victime} partage sa position avec vous.`
      : `${victime} est en danger. Ouvrez l'application immédiatement.`;

    // Envoyer une notification par appareil
    const envois = tokens.map((t) =>
      fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: {
            token: t.token,
            notification: { title: titre, body: corps },
            data: {
              type: "urgence",
              urgence: "true",
              alerteId: String(payload.alerteId || ""),
              victime: String(payload.victime?.ph || ""),
            },
            android: {
              priority: "high",
              notification: {
                channel_id: "urgences_alerte_ci",
                sound: "default",
                notification_priority: "PRIORITY_MAX",
                visibility: "PUBLIC",
              },
            },
          },
        }),
      }).catch(() => null)
    );

    await Promise.all(envois);
    return new Response(`Notifications envoyées : ${tokens.length}`, { status: 200 });
  } catch (e) {
    return new Response(`Erreur : ${e.message}`, { status: 500 });
  }
});
