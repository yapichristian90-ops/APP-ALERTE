-- ═══════════════════════════════════════════════════════════════════════
-- DÉCLENCHEUR PUSH — appelle automatiquement l'Edge Function « envoyer-push »
-- chaque fois qu'une urgence est insérée dans la table « diffusions ».
--
-- À exécuter dans SQL Editor APRÈS avoir déployé l'Edge Function.
-- Remplace les DEUX valeurs entre chevrons avant d'exécuter.
-- ═══════════════════════════════════════════════════════════════════════

-- Extension permettant les appels HTTP depuis la base
create extension if not exists pg_net;

-- Fonction déclenchée à chaque nouvelle diffusion
create or replace function public.notifier_urgence()
returns trigger language plpgsql security definer as $$
declare
  est_urgence boolean;
begin
  -- On ne notifie que les urgences (pas les diffusions publiques ni les « fin »)
  est_urgence := (new.payload->>'urgence')::boolean is true
                 and (new.payload->>'fin') is distinct from 'true';
  if est_urgence then
    perform net.http_post(
      -- ⬇️ REMPLACER par l'URL de votre Edge Function (voir le guide)
      url := 'https://VOTRE-REF.supabase.co/functions/v1/envoyer-push',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        -- ⬇️ REMPLACER par votre clé service_role (Settings > API)
        'Authorization', 'Bearer VOTRE_CLE_SERVICE_ROLE'
      ),
      body := jsonb_build_object('record', row_to_json(new))
    );
  end if;
  return new;
end;
$$;

-- Brancher le déclencheur sur la table diffusions
drop trigger if exists trg_notifier_urgence on public.diffusions;
create trigger trg_notifier_urgence
  after insert on public.diffusions
  for each row execute function public.notifier_urgence();
