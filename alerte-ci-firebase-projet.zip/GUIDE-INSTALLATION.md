# 📱 Alerte CI — Construire l'APK avec notifications push

Ce dossier contient tout le nécessaire pour produire l'application **avec les
notifications qui s'affichent même écran verrouillé / application fermée**.

La compilation se fait gratuitement sur les serveurs de GitHub (GitHub Actions),
parce qu'elle a besoin d'accéder aux serveurs de Google — ce qui n'est pas
possible depuis l'atelier où le reste a été préparé.

Aucune connaissance technique n'est nécessaire : suivez les étapes dans l'ordre.

---

## 🅰️ PARTIE 1 — Obtenir l'APK (≈ 15 minutes)

### 1. Créer un dépôt GitHub
1. Allez sur https://github.com et connectez-vous (créez un compte si besoin).
2. Cliquez sur **New** (nouveau dépôt).
3. Nom : `alerte-ci-app`. Laissez-le **Private**. Cliquez **Create repository**.

### 2. Envoyer ce dossier dans le dépôt
Le plus simple, sans logiciel :
1. Sur la page du dépôt vide, cliquez **uploading an existing file**.
2. Glissez-déposez **tout le contenu de ce dossier** (le fichier
   `google-services.json`, les dossiers `www`, `.github`, `supabase`, etc.).
3. En bas, cliquez **Commit changes**.

> ⚠️ Vérifiez que le fichier `.github/workflows/build-apk.yml` est bien présent
> (GitHub garde parfois les dossiers commençant par un point ; s'il manque,
> recréez-le via **Add file → Create new file** en collant son contenu).

### 3. Lancer la compilation
1. Onglet **Actions** du dépôt.
2. Si GitHub demande d'activer les workflows, acceptez.
3. La compilation démarre seule. Sinon : cliquez le workflow
   **« Construire l'APK Alerte CI »** puis **Run workflow**.
4. Patientez ~5 minutes (pastille verte = terminé).

### 4. Télécharger l'APK
1. Cliquez sur l'exécution terminée.
2. En bas, section **Artifacts**, cliquez **alerte-ci-app** pour télécharger.
3. Décompressez le `.zip` : vous obtenez **app-debug.apk**.
4. Transférez-le sur le téléphone et installez (désinstallez d'abord toute
   version précédente de l'app utilisateur).

✅ **À ce stade, l'application fonctionne**, avec le micro, le GPS, la sirène,
la carte, l'agent IA. Pour que les alertes **réveillent le téléphone verrouillé**,
faites la partie 2.

---

## 🅱️ PARTIE 2 — Activer l'envoi des notifications (≈ 20 minutes)

Le téléphone sait **recevoir** les notifications. Il faut maintenant que le
serveur les **envoie** quand une urgence est déclenchée.

### 1. Récupérer la clé du compte de service Firebase
1. Console Firebase → votre projet **ci-alerteci-appli**.
2. ⚙️ (roue dentée) → **Paramètres du projet** → onglet **Comptes de service**.
3. Cliquez **Générer une nouvelle clé privée** → **Générer la clé**.
4. Un fichier `.json` se télécharge. Gardez-le : c'est le **compte de service**.

### 2. Déployer l'Edge Function sur Supabase
Dans le tableau de bord Supabase de votre projet :
1. Menu **Edge Functions** → **Create a function**.
2. Nom : `envoyer-push`.
3. Collez le contenu de `supabase/functions/envoyer-push/index.ts`.
4. Déployez.

Puis ajoutez le secret (le compte de service) :
1. **Edge Functions → Manage secrets** (ou **Settings → Edge Functions**).
2. Nouveau secret : nom `FIREBASE_SERVICE_ACCOUNT`, valeur = **tout le contenu**
   du fichier `.json` téléchargé à l'étape 1 (copier-coller intégral).
3. Enregistrez. (Les secrets `SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY`
   sont déjà fournis automatiquement par Supabase.)

### 3. Brancher le déclencheur automatique
1. Ouvrez `supabase/declencheur-push.sql`.
2. Remplacez-y **deux valeurs** :
   - `VOTRE-REF` → la référence de votre projet (visible dans l'URL du tableau
     de bord : `https://supabase.com/dashboard/project/VOTRE-REF`).
   - `VOTRE_CLE_SERVICE_ROLE` → **Settings → API → service_role** (clé secrète).
3. Copiez le SQL corrigé dans **SQL Editor → New query → Run**.

✅ **Terminé.** Désormais, quand une alerte Violence ou un partage
d'enlèvement est déclenché, les téléphones des contacts ciblés sonnent et
affichent la notification **même verrouillés ou application fermée**.

---

## 🔁 Modifier l'application plus tard

Pour changer le contenu de l'app, remplacez `www/assets/app.js` par la nouvelle
version, envoyez-la sur GitHub : la compilation se relance et produit un APK à
jour. Rien d'autre à refaire.

---

## ❓ Aide

- **La compilation échoue (pastille rouge)** : ouvrez l'exécution, lisez l'étape
  en rouge. Le plus souvent, un fichier n'a pas été envoyé — vérifiez que
  `google-services.json` est bien à la racine et `.github/workflows/build-apk.yml`
  bien présent.
- **Les notifications n'arrivent pas** : vérifiez que le compte de service a été
  collé en entier dans le secret `FIREBASE_SERVICE_ACCOUNT`, et que les deux
  valeurs du SQL ont bien été remplacées.
- **L'app ne s'installe pas** : désinstallez l'ancienne version d'abord (deux
  apps signées différemment ne peuvent pas coexister sous le même nom).
